const adminAddress = '0xecbc81F6f5Ff304e0C8C36F8200320289F191e31'; // Replace with actual admin address
const contractAddress = '0x1537E2f983C2CA77bA8B8378d60794d8209a859C'; // Replace with your deployed contract address

const abi = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			}
		],
		"name": "addCandidate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_admin",
				"type": "address"
			}
		],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "newAdmin",
				"type": "address"
			}
		],
		"name": "AdminTransferred",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "name",
				"type": "string"
			}
		],
		"name": "CandidateAdded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			}
		],
		"name": "CandidateDeleted",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "declareWinner",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "deleteCandidate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "endVoting",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "startVoting",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "newAdmin",
				"type": "address"
			}
		],
		"name": "transferOwnership",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "vote",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "voter",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "candidateId",
				"type": "uint256"
			}
		],
		"name": "Voted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [],
		"name": "VotingEnded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [],
		"name": "VotingStarted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "winnerId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "winnerName",
				"type": "string"
			}
		],
		"name": "WinnerDeclared",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "candidates",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "voteCount",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "candidatesCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_candidateId",
				"type": "uint256"
			}
		],
		"name": "getCandidate",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getCandidatesCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "voters",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "votingActive",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "votingEnded",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];

let web3;
let contract;
let accounts;

window.onload = async () => {
    if (window.ethereum) {
        web3 = new Web3(window.ethereum);
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            accounts = await web3.eth.getAccounts();
            document.getElementById('wallet-address').textContent = accounts[0];
            contract = new web3.eth.Contract(abi, contractAddress);
            initializePage();
        } catch (error) {
            alert("You need to connect a wallet to interact with the voting system.");
        }
    } else {
        alert("Please install MetaMask to use this app.");
    }
};

const initializePage = async () => {
    if (accounts[0].toLowerCase() === adminAddress.toLowerCase()) {
        document.getElementById('admin-dashboard').style.display = 'block';
        document.getElementById('user-dashboard').style.display = 'none';
        loadCandidatesForAdmin();
    } else {
        document.getElementById('admin-dashboard').style.display = 'none';
        document.getElementById('user-dashboard').style.display = 'block';
        loadCandidatesForUser();
    }
};

const loadCandidatesForAdmin = async () => {
    const candidatesCount = await contract.methods.getCandidatesCount().call();
    const tableBody = document.querySelector('#candidates-table tbody');
    tableBody.innerHTML = '';
    for (let i = 1; i <= candidatesCount; i++) {
        const candidate = await contract.methods.getCandidate(i).call();
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${candidate[0]}</td>
            <td>${candidate[1]}</td>
            <td><button onclick="deleteCandidate(${i})">Delete</button></td>
        `;
        tableBody.appendChild(row);
    }
};

const loadCandidatesForUser = async () => {
    const candidatesCount = await contract.methods.getCandidatesCount().call();
    const tableBody = document.querySelector('#user-candidates-table tbody');
    tableBody.innerHTML = '';
    for (let i = 1; i <= candidatesCount; i++) {
        const candidate = await contract.methods.getCandidate(i).call();
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${candidate[0]}</td>
            <td>${candidate[1]}</td>
            <td><button onclick="vote(${i})">Vote</button></td>
        `;
        tableBody.appendChild(row);
    }
};

const vote = async (candidateId) => {
    await contract.methods.vote(candidateId).send({ from: accounts[0] });
    alert("Vote successful!");
};

const deleteCandidate = async (candidateId) => {
    await contract.methods.deleteCandidate(candidateId).send({ from: accounts[0] });
    alert("Candidate deleted!");
    loadCandidatesForAdmin();
};

const addCandidate = async () => {
    const candidateName = document.getElementById('new-candidate-name').value;
    if (!candidateName) {
        alert("Candidate name cannot be empty");
        return;
    }
    await contract.methods.addCandidate(candidateName).send({ from: accounts[0] });
    alert("Candidate added!");
    loadCandidatesForAdmin();
};

const startVoting = async () => {
    await contract.methods.startVoting().send({ from: accounts[0] });
};

const endVoting = async () => {
    await contract.methods.endVoting().send({ from: accounts[0] });
};

const declareWinner = async () => {
    await contract.methods.declareWinner().send({ from: accounts[0] });
    const winnerId = await contract.methods.getCandidatesCount().call();
    const winner = await contract.methods.getCandidate(winnerId).call();
    document.getElementById('winner-name').textContent = winner[0];
    document.getElementById('winner-votes').textContent = winner[1];
    document.getElementById('winner').style.display = 'block';
};
